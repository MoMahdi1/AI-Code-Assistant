'use client'

import { useState, useRef, useEffect } from 'react'
import Navbar from '@/components/navbar'
import ChatArea from '@/components/chat-area'
import ChatInput from '@/components/chat-input'
import EmptyState from '@/components/empty-state'

export interface Message {
  id: string
  role: 'user' | 'assistant'
  content: string
  timestamp: Date
}

export default function Home() {
  const [messages, setMessages] = useState<Message[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSendMessage = async (content: string) => {
    if (!content.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setIsLoading(true)

    // Simulate AI response - in production, this would call an API
    setTimeout(() => {
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: generateMockResponse(content),
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, assistantMessage])
      setIsLoading(false)
    }, 1500)
  }

  const handleClearChat = () => {
    setMessages([])
  }

  return (
    <div className="flex flex-col h-screen bg-background">
      <Navbar onClearChat={handleClearChat} />
      <div className="flex-1 overflow-hidden flex flex-col">
        {messages.length === 0 ? (
          <EmptyState />
        ) : (
          <ChatArea messages={messages} isLoading={isLoading} messagesEndRef={messagesEndRef} />
        )}
      </div>
      <ChatInput onSendMessage={handleSendMessage} isLoading={isLoading} />
    </div>
  )
}

function generateMockResponse(userInput: string): string {
  const responses: { [key: string]: string } = {
    'hello': '```javascript\n// Hello World!\nconsole.log("Hello, AI Code Assistant!");\n```\n\nHello! I\'m your AI Code Assistant. I can help you write, debug, and understand code. Try asking me to:\n\n- Generate code snippets\n- Explain programming concepts\n- Debug your code\n- Refactor code for better practices',
    
    'function': '```javascript\n// Example function\nfunction greet(name) {\n  const greeting = `Hello, ${name}!`;\n  return greeting;\n}\n\n// Usage\nconsole.log(greet("Developer"));\n```\n\nI\'ve created a simple greeting function for you. Functions are reusable blocks of code that perform specific tasks. This one takes a name parameter and returns a personalized greeting.',
    
    'react': '```javascript\n// React Functional Component\nimport { useState } from "react";\n\nexport default function Counter() {\n  const [count, setCount] = useState(0);\n  \n  return (\n    <div>\n      <p>Count: {count}</p>\n      <button onClick={() => setCount(count + 1)}>\n        Increment\n      </button>\n    </div>\n  );\n}\n```\n\nThis is a React functional component with state. It demonstrates the `useState` hook for managing component state and includes an interactive button that increments the counter.',
    
    'default': '```javascript\n// Processing your request...\nconst ai = {\n  capability: "code generation & explanation",\n  models: ["GPT-4", "Claude", "Gemini"],\n  features: [\n    "Syntax highlighting",\n    "Code explanation",\n    "Refactoring suggestions",\n    "Error debugging"\n  ]\n};\n\nconsole.log("Ready to assist!");\n```\n\nI can help you with various programming tasks! I can generate code, explain concepts, debug errors, and help with refactoring. Feel free to ask me anything related to code!'
  }

  const lowerInput = userInput.toLowerCase()
  let response = responses.default

  for (const key in responses) {
    if (lowerInput.includes(key)) {
      response = responses[key]
      break
    }
  }

  return response
}
